"""Exercise documented topology.py entrypoint/key CLI/startup order in a clean lab."""
import json,os,shlex,signal,socket,subprocess,sys,tempfile,time
from pathlib import Path
ROOT=Path('/home/akash/sdn-final-simplified-20261029')
OUT=Path('/home/akash/sdn-final-evidence-20261029-165913-demo')

def main():
    OUT.mkdir(mode=0o700,exist_ok=False);events=[];topo=None;controller=None;pids=[]
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
    for key in ['SDN_CONTROL_HOST','SDN_CONTROL_ALLOWED_PEER','SDN_CONTROL_PORT','SDN_CONTROLLER_HOST','SDN_CONTROLLER_PORT','AUTH_LEASE_SECONDS','AUTH_LOCKOUT_SECONDS']:
        env.pop(key,None)
    def cmd(argv):
        r=subprocess.run(argv,text=True,capture_output=True,env=env,timeout=10)
        events.append(dict(argv=argv,exit_code=r.returncode,output=r.stdout+r.stderr));return r
    with tempfile.TemporaryDirectory(prefix='sdn-smoke-') as private:
        key=Path('/home/akash/.local/state/sdn-final-simplified-20261029/control.key');key.parent.mkdir(mode=0o700, parents=True, exist_ok=True);env['SDN_CONTROL_SECRET_FILE']=str(key)
        try:
            if os.geteuid()!=0:raise RuntimeError('Approved root execution required')
            if cmd(['ovs-vsctl','br-exists','s1']).returncode!=2:raise RuntimeError('Existing bridge; refusing startup')
            for name in ['ctrlroot0','ctrlovs0']:
                if cmd(['ip','link','show',name]).returncode==0:raise RuntimeError('Existing interface')
            for port in [6653,9999,9000,8080]:
                with socket.socket() as s:
                    s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind(('0.0.0.0',port))
            if not key.exists():
                r=cmd([sys.executable,str(ROOT/'control_security.py'),'--generate-key',str(key)])
                if r.returncode:raise RuntimeError('Key CLI failed')
            if key.stat().st_mode&0o077:raise RuntimeError('Private key permissions invalid')
            with (OUT/'topology.log').open('w') as log:
                topo=subprocess.Popen([sys.executable,'-B',str(ROOT/'topology.py')],cwd=ROOT,env=env,stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT,text=True)
            events.append(dict(argv=topo.args,pid=topo.pid))
            deadline=time.monotonic()+20
            while cmd(['ip','link','show','ctrlroot0']).returncode:
                if topo.poll() is not None or time.monotonic()>deadline:raise RuntimeError('Topology CLI did not start')
                time.sleep(.2)
            with (OUT/'controller.log').open('w') as log:
                controller=subprocess.Popen([str(ROOT/'.venv311/bin/osken-manager'),'--ofp-listen-host','127.0.0.1','--ofp-tcp-listen-port','6653',str(ROOT/'controller.py')],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT, user='akash', group='akash')
            events.append(dict(argv=controller.args,pid=controller.pid))
            deadline=time.monotonic()+25
            while True:
                table=cmd(['ovs-ofctl','-O','OpenFlow13','dump-flows','s1'])
                if table.returncode==0 and 'priority=100' in table.stdout:break
                if controller.poll() is not None or time.monotonic()>deadline:raise RuntimeError('Controller startup failed')
                time.sleep(.2)
            deadline=time.monotonic()+5
            while 'mininet> ' not in (OUT/'topology.log').read_text():
                if time.monotonic()>deadline:raise RuntimeError('No Mininet prompt')
                time.sleep(.05)
            def cli(command):
                offset=len((OUT/'topology.log').read_text())
                events.append(dict(mininet_command=command))
                topo.stdin.write(command+'\n');topo.stdin.flush()
                deadline=time.monotonic()+100
                while 'mininet> ' not in (OUT/'topology.log').read_text()[offset:]:
                    if topo.poll() is not None or time.monotonic()>deadline:
                        raise RuntimeError('CLI command did not complete')
                    time.sleep(.05)

            evidence=ROOT/'logs'
            cli('sh mkdir -p '+shlex.quote(str(evidence))+'; chmod 700 '+shlex.quote(str(evidence)))
            for host,name,logname in [('h_auth','auth_server.py','auth-console.log'),('h_srv','protected_service.py','service.log')]:
                pidfile=ROOT/'logs'/(host+'.pid');log=evidence/logname
                launch=f'echo $$ > {shlex.quote(str(pidfile))}; exec /usr/bin/python3 -B -u ./{name}'
                command=f'{host} env SDN_CONTROL_SECRET_FILE={shlex.quote(str(key))} AUTH_LOG_FILE={shlex.quote(str(evidence/"security.log"))} sh -c {shlex.quote(launch)} > {shlex.quote(str(log))} 2>&1 &'
                cli(command)
                deadline=time.monotonic()+30
                while not pidfile.exists() or not log.exists() or 'listening on' not in log.read_text():
                    if time.monotonic()>deadline:raise RuntimeError('Demo service did not start: '+host)
                    time.sleep(.1)
                pid=int(pidfile.read_text());pids.append((pid,'./'+name))
            def check(command, expected=0):
                cli(command+'; echo CHECK_EXIT=$?')
                segment=(OUT/'topology.log').read_text().split('CHECK_EXIT=')[-1]
                if not segment.startswith(str(expected)+'\n'):
                    raise RuntimeError('Unexpected demo exit: '+command)
            def qualify(label):
                check('h_srv python3 -B demo_checks.py service')
                table=cmd(['ovs-ofctl','-O','OpenFlow13','dump-flows','s1']).stdout
                (OUT/(label+'-flows.txt')).write_text(table)
                if 'priority=100' not in table or 'priority=200' in table:
                    raise RuntimeError('Unexpected deny/grant policy')
            check('h_srv python3 -B demo_checks.py service')
            check('h1 python3 -B demo_checks.py denied',2);qualify('initial-deny')
            check('h1 python3 -B client.py')
            check('h1 python3 -B demo_checks.py denied',2);qualify('after-logout')
            # Observe active 60-second rule while the CLI expiry check is waiting.
            import threading
            def capture_grant():
                deadline=time.monotonic()+20
                while time.monotonic()<deadline:
                    r=cmd(['ovs-ofctl','-O','OpenFlow13','dump-flows','s1'])
                    if 'hard_timeout=60' in r.stdout and 'nw_src=10.0.0.1' in r.stdout:
                        (OUT/'active-default-expiry-flows.txt').write_text(r.stdout); return
                    time.sleep(.2)
            capture=threading.Thread(target=capture_grant);capture.start()
            check('h1 python3 -B demo_checks.py expiry',2);capture.join()
            active=(OUT/'active-default-expiry-flows.txt').read_text()
            if 'hard_timeout=60' not in active or 'nw_src=10.0.0.1' not in active:
                raise RuntimeError('Missing default 60-second grant')
            qualify('default-expiry')
            check('h1 python3 -B demo_checks.py concurrent');qualify('concurrency-cleanup')
            check('h2 python3 -B demo_checks.py lockout --recover');qualify('lockout-recovery')
            controller.send_signal(signal.SIGINT);controller.wait(10)
            check('h1 python3 -B demo_checks.py controller-down');qualify('controller-down')
            for text in ['LOGIN_SUCCESS','ACCESS_UPDATED']:
                if text not in (evidence/'security.log').read_text():raise RuntimeError('Auth log missing '+text)
            if '[SERVICE] Request handled from' not in (evidence/'service.log').read_text():raise RuntimeError('Access log missing')
            events.append(dict(check='private-retained-logs',directory=str(evidence),mode=oct(evidence.stat().st_mode&0o777),result='auth/service logs retained; normal client exits 0; healthy service plus h2 timeout'))
            table=cmd(['ovs-ofctl','-O','OpenFlow13','dump-flows','s1'])
            (OUT/'final-flows.txt').write_text(table.stdout)
            if 'priority=200' in table.stdout or 'priority=100' not in table.stdout:raise RuntimeError('Unexpected final policy')
            print('Private README log capture + topology CLI + client login/access/logout + qualified h2 denial: PASS',flush=True)
        finally:
            # Resolve every PID emitted by our own exec shell before stopping it.
            for host,name in [('h_srv','protected_service.py'),('h_auth','auth_server.py')]:
                pidfile=ROOT/'logs'/(host+'.pid')
                if pidfile.exists():
                    pair=(int(pidfile.read_text()),'./'+name)
                    if pair not in pids:pids.append(pair)
            for pid,path in pids:
                try:
                    args=Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
                    if path.encode() in args:
                        host='h_auth' if path=='./auth_server.py' else 'h_srv'
                        if topo is not None and topo.poll() is None:
                            cli(host+' kill -TERM $(cat logs/'+host+'.pid)')
                        else:
                            os.kill(pid,signal.SIGTERM)
                        events.append(dict(stop_owned_pid=pid,signal='SIGTERM',host=host))
                except ProcessLookupError:pass
                except FileNotFoundError:pass
            if topo is not None:
                if topo.poll() is None:
                    topo.stdin.write('exit\n');topo.stdin.flush()
                    try:topo.wait(10)
                    except subprocess.TimeoutExpired:topo.terminate();topo.wait(5)
                events.append(dict(topology_exit_code=topo.returncode))
            if controller is not None:
                if controller.poll() is None:
                    controller.send_signal(signal.SIGINT)
                    try:controller.wait(5)
                    except subprocess.TimeoutExpired:controller.kill();controller.wait(5)
                events.append(dict(controller_exit_code=controller.returncode))
            after=cmd(['ovs-vsctl','show']);(OUT/'ovs-after.txt').write_text(after.stdout)
            cmd(['ss','-ltnp']);cmd(['ip','-brief','address'])
            (OUT/'commands.json').write_text(json.dumps(events,indent=2))

if __name__=='__main__':main()
